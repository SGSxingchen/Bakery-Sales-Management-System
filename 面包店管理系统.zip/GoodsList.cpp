#include "GoodsList.h"

GoodsList::GoodsList() {}

GoodsList::~GoodsList() {}
